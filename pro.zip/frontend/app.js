// ============================================
// Saft NutriCalc PRO - Frontend Application
// ============================================

// Detect base path automatically (works at root or under /nutricalc/)
const BASE_PATH = (() => {
  const p = window.location.pathname;
  // If we're under /nutricalc/, use that as base
  const m = p.match(/^(\/[^\/]+)\//);
  if (m && m[1] !== '/api') return m[1];
  return '';
})();
const API_BASE = BASE_PATH + '/api';
const SUPPORTED_LANGS = ['it', 'en', 'es'];

// State
let currentLang = localStorage.getItem('saft_lang') || (SUPPORTED_LANGS.includes(navigator.language.slice(0,2)) ? navigator.language.slice(0,2) : 'en');
let i18n = null;
let FOODS = [];
let currentUser = null;
let currentSection = 'calculator';
let currentClient = null;
let recipe = []; // current recipe being built in calculator
let activeFilters = new Set();
let currentCategory = 'all';

// ============ API HELPER ============
async function api(path, options = {}) {
  const opts = {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  };
  if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);

  const res = await fetch(API_BASE + path, opts);

  if (res.status === 401 && path !== '/auth/login' && !path.startsWith('/setup')) {
    showLogin();
    throw new Error('Unauthorized');
  }
  if (res.status === 204) return null;

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.detail || `HTTP ${res.status}`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

// ============ I18N ============
async function loadLanguage(lang) {
  try {
    const r = await fetch(`${API_BASE}/data/lang/${lang}`);
    i18n = await r.json();
    currentLang = lang;
    localStorage.setItem('saft_lang', lang);
    document.documentElement.lang = lang;
    applyTranslations();
    highlightLang();
  } catch(e) { console.error('Lang load failed', e); }
}

async function setLanguage(lang) {
  if (lang === currentLang || !SUPPORTED_LANGS.includes(lang)) return;
  await loadLanguage(lang);
  // Re-render current section
  switchSection(currentSection);
}

function highlightLang() {
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === currentLang));
}

function t(k) { return (i18n?.ui?.[k]) || k; }
function tCat(c) { return (i18n?.categories?.[c]) || c; }
function tFood(id) { return (i18n?.foods?.[id]) || `#${id}`; }
function tAllergen(a) { return (i18n?.allergens?.[a]) || a; }

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => el.textContent = t(el.getAttribute('data-i18n')));
  document.querySelectorAll('[data-i18n-html]').forEach(el => el.innerHTML = t(el.getAttribute('data-i18n-html')));
  document.querySelectorAll('[data-i18n-attr]').forEach(el => {
    const [a, k] = el.getAttribute('data-i18n-attr').split(':');
    el.setAttribute(a, t(k));
  });
}

// ============ INIT ============
async function init() {
  try {
    // Load food data
    const fr = await fetch(API_BASE + '/data/foods');
    FOODS = await fr.json();
    await loadLanguage(currentLang);
  } catch(e) {
    document.getElementById('splash').innerHTML = '<p style="color:var(--md-sys-color-error)">⚠️ Failed to load data</p>';
    return;
  }

  // Check setup status
  const setupRes = await fetch(API_BASE + '/setup/status').then(r => r.json());
  if (setupRes.setup_needed) {
    hideSplash();
    showSetup();
    return;
  }

  // Try to authenticate (check if cookie session is valid)
  try {
    currentUser = await api('/auth/me');
    hideSplash();
    showApp();
  } catch(e) {
    hideSplash();
    showLogin();
  }
}

function hideSplash() {
  const sp = document.getElementById('splash');
  sp.classList.add('fade');
  setTimeout(() => sp.style.display = 'none', 300);
}

function showSetup() {
  document.getElementById('setupScreen').style.display = 'flex';
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('app').style.display = 'none';
}

function showLogin() {
  document.getElementById('setupScreen').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  document.getElementById('app').style.display = 'none';
}

function showApp() {
  document.getElementById('setupScreen').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  document.getElementById('userName').textContent = currentUser?.username || '—';
  switchSection('calculator');
}

// ============ AUTH ACTIONS ============
async function doSetup(e) {
  e.preventDefault();
  const form = e.target;
  const f = Object.fromEntries(new FormData(form));
  const errEl = document.getElementById('setupError');
  errEl.style.display = 'none';

  if (f.password !== f.password_confirm) {
    errEl.textContent = t('err_password_mismatch') || 'Le password non coincidono';
    errEl.style.display = 'block';
    return false;
  }
  try {
    await api('/setup', {
      method: 'POST',
      body: {
        username: f.username,
        password: f.password,
        full_name: f.full_name,
        email: f.email || null,
        preferred_lang: currentLang,
      },
    });
    currentUser = await api('/auth/me');
    showApp();
  } catch(err) {
    errEl.textContent = err.message || t('err_setup_failed');
    errEl.style.display = 'block';
  }
  return false;
}

async function doLogin(e) {
  e.preventDefault();
  const form = e.target;
  const f = Object.fromEntries(new FormData(form));
  const errEl = document.getElementById('loginError');
  errEl.style.display = 'none';

  try {
    await api('/auth/login', {
      method: 'POST',
      body: { username: f.username, password: f.password },
    });
    currentUser = await api('/auth/me');
    showApp();
  } catch(err) {
    errEl.textContent = t('err_invalid_credentials') || 'Credenziali non valide';
    errEl.style.display = 'block';
  }
  return false;
}

async function doLogout() {
  try { await api('/auth/logout', { method: 'POST' }); } catch(e) {}
  currentUser = null;
  showLogin();
}

function toggleUserMenu() {
  document.getElementById('userDropdown').classList.toggle('show');
}

// Close user menu on outside click
document.addEventListener('click', e => {
  if (!e.target.closest('.user-menu')) {
    document.getElementById('userDropdown')?.classList.remove('show');
  }
});

// ============ SECTION ROUTING ============
function switchSection(name) {
  currentSection = name;
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.section === name));
  const main = document.getElementById('mainContainer');
  main.innerHTML = '<div class="section active"></div>';
  const container = main.firstElementChild;

  switch(name) {
    case 'calculator': renderCalculator(container); break;
    case 'clients': renderClientsList(container); break;
    case 'client-detail': renderClientDetail(container); break;
    case 'recipes': renderRecipes(container); break;
  }
}

// ============ CALCULATOR (the original NutriCalc) ============
let selectedFood = null;
let currentWeight = 100;

function renderCalculator(container) {
  container.innerHTML = `
    <div class="section-header">
      <h2>${t('nav_calculator')}</h2>
      <div class="actions">
        <button class="btn btn-secondary" onclick="clearRecipe()">
          <span class="material-icons-round">delete_sweep</span>
          <span>${t('recipe_clear')}</span>
        </button>
        ${recipe.length > 0 ? `
          <button class="btn btn-green" onclick="openSaveRecipeModal()">
            <span class="material-icons-round">bookmark_add</span>
            <span>${t('save_recipe')}</span>
          </button>
        ` : ''}
      </div>
    </div>

    <div class="calc-layout">
      <div class="calc-sidebar">
        <div class="search-bar">
          <span class="material-icons-round">search</span>
          <input type="text" id="foodSearch" placeholder="${t('search_placeholder')}" oninput="renderFoodList()">
          <span class="food-count-pill" id="foodCountPill">0</span>
        </div>
        <div class="category-chips" id="categoryChips"></div>
        <div class="food-list" id="foodList"></div>
      </div>
      <div class="calc-main" id="calcMain">
        <button class="close-sheet" onclick="closeMobileSheet()">
          <span class="material-icons-round">close</span>
        </button>
        <div id="calcContent">
          <div class="empty-state">
            <span class="material-icons-round">touch_app</span>
            <h3>${t('detail_empty_title') || t('detail_empty')}</h3>
            <p>${t('detail_empty')}</p>
          </div>
        </div>
        <div id="recipeBox"></div>
      </div>
    </div>

    <style>
      .calc-layout {
        display: grid; grid-template-columns: 360px 1fr; gap: 20px;
        height: calc(100vh - 64px - 48px - 60px);
      }
      .calc-sidebar {
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: var(--radius); padding: 16px;
        display: flex; flex-direction: column; gap: 12px; overflow: hidden;
      }
      .calc-main {
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: var(--radius); padding: 20px;
        overflow-y: auto;
      }
      .food-count-pill {
        background: var(--md-sys-color-primary); color: white;
        font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px;
      }
      .category-chips {
        display: flex; gap: 6px; overflow-x: auto; overflow-y: hidden; flex-wrap: nowrap;
        flex-shrink: 0;
        min-width: 0; width: 100%;
        padding-bottom: 6px;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: thin;
        scrollbar-color: var(--md-sys-color-primary) transparent;
        cursor: grab;
      }
      .category-chips:active { cursor: grabbing; }
      .category-chips::-webkit-scrollbar { height: 6px; }
      .category-chips::-webkit-scrollbar-track { background: var(--bg-surface); border-radius: 3px; }
      .category-chips::-webkit-scrollbar-thumb { background: var(--md-sys-color-primary); border-radius: 3px; }
      .category-chips::-webkit-scrollbar-thumb:hover { background: var(--saft-orange); }
      .chip {
        flex-shrink: 0; white-space: nowrap; padding: 6px 14px;
        border-radius: 20px; font-size: 12px; font-weight: 500;
        background: var(--chip-bg); color: var(--on-bg-muted);
        border: 1px solid var(--border); cursor: pointer;
        transition: all var(--transition);
        user-select: none;
      }
      .chip.active { background: var(--md-sys-color-primary); color: white; border-color: var(--md-sys-color-primary); }
      .food-list { flex: 1; overflow-y: auto; margin: 0 -16px -16px; padding: 0 16px 16px; }
      .food-item {
        display: flex; align-items: center; gap: 10px; padding: 8px;
        border-radius: 10px; cursor: pointer; transition: background 0.15s;
      }
      .food-item:hover { background: var(--bg-surface); }
      .food-item.selected { background: var(--chip-bg); }
      .food-item-emoji {
        width: 36px; height: 36px; border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        font-size: 18px; flex-shrink: 0;
      }
      .food-item-info { flex: 1; min-width: 0; }
      .food-item-name { font-size: 13px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .food-item-sub { font-size: 11px; color: var(--on-bg-muted); }
      .food-item-kcal { font-size: 13px; font-weight: 700; color: var(--kcal-color); }
      .section-title {
        font-size: 10px; font-weight: 700; text-transform: uppercase;
        letter-spacing: 0.8px; color: var(--on-bg-subtle); padding: 8px 0 4px;
      }
      .macros-grid {
        display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin: 16px 0;
      }
      .macro-box { text-align: center; padding: 12px; background: var(--bg-surface); border-radius: 10px; }
      .macro-box .v { font-size: 18px; font-weight: 700; }
      .macro-box .l { font-size: 10px; color: var(--on-bg-muted); }
      .recipe-item-row {
        display: flex; align-items: center; gap: 10px;
        background: var(--bg-surface); border-radius: 10px; padding: 8px 12px; margin-bottom: 6px;
      }
      .recipe-item-row input {
        width: 60px; text-align: center; padding: 4px;
        background: var(--input-bg); border: 1px solid var(--border); border-radius: 6px;
        font-family: inherit; font-size: 13px; font-weight: 600;
      }
      @media (max-width: 900px) {
        .calc-layout {
          grid-template-columns: 1fr; height: auto;
          display: block;
        }
        .calc-sidebar {
          max-height: none;
          height: calc(100vh - 64px - 70px - 48px - 80px);
        }
        .calc-main {
          position: fixed; left: 0; right: 0; bottom: 70px;
          z-index: 50; background: var(--bg-card);
          border-radius: 20px 20px 0 0;
          box-shadow: 0 -8px 32px rgba(0,0,0,0.18);
          max-height: 75vh; overflow-y: auto;
          padding-bottom: calc(20px + env(safe-area-inset-bottom));
          transform: translateY(100%);
          transition: transform 0.3s cubic-bezier(0.2,0,0,1);
          border: none;
          padding-top: 8px;
          /* Hidden by default on mobile until selectFood triggers open */
          visibility: hidden;
        }
        .calc-main.open { transform: translateY(0); visibility: visible; }
        .calc-main::before {
          content: ''; display: block;
          width: 40px; height: 4px; border-radius: 2px;
          background: var(--border-strong); margin: 0 auto 12px;
        }
        .calc-main .close-sheet {
          position: absolute; top: 10px; left: 12px;
          width: 32px; height: 32px; border-radius: 50%;
          background: var(--chip-bg); border: none; cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          z-index: 2;
        }
        .calc-main .close-sheet .material-icons-round { font-size: 18px; color: var(--on-bg-muted); }
        /* Hide the empty-state placeholder on mobile - sheet only shows when food selected */
        .calc-main .empty-state { display: none; }
      }
      @media (min-width: 901px) {
        .calc-main .close-sheet { display: none; }
      }
    </style>
  `;
  buildCategoryChips();
  renderFoodList();
  renderRecipeBox();
}

function buildCategoryChips() {
  const CATEGORIES = ['all','verdura','frutta','carne','pesce','formaggio','latticini','cereali','legumi','uova','oli','dolci','bevande','salumi','noci','integratori'];
  const CAT_EMOJI = {all:'🍽️',verdura:'🥦',frutta:'🍎',carne:'🥩',pesce:'🐟',formaggio:'🧀',latticini:'🥛',cereali:'🌾',legumi:'🫘',uova:'🥚',oli:'🫒',dolci:'🍫',bevande:'☕',salumi:'🥓',noci:'🥜',integratori:'💪'};
  const el = document.getElementById('categoryChips');
  el.innerHTML = CATEGORIES.map(c =>
    `<div class="chip${c===currentCategory?' active':''}" onclick="filterCategory('${c}')">${CAT_EMOJI[c]} ${tCat(c)}</div>`
  ).join('');

  // Wheel scroll: convert vertical to horizontal
  el.onwheel = (e) => {
    if (e.deltaY !== 0) {
      e.preventDefault();
      el.scrollLeft += e.deltaY;
    }
  };

  // Drag to scroll
  let isDown = false, startX = 0, scrollLeftStart = 0;
  el.onmousedown = (e) => {
    isDown = true;
    startX = e.pageX - el.offsetLeft;
    scrollLeftStart = el.scrollLeft;
  };
  el.onmouseleave = () => { isDown = false; };
  el.onmouseup = () => { isDown = false; };
  el.onmousemove = (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - el.offsetLeft;
    el.scrollLeft = scrollLeftStart - (x - startX);
  };
}

function filterCategory(c) {
  currentCategory = c;
  buildCategoryChips();
  renderFoodList();
}

function catColor(c) {
  const m = {verdura:'#4CAF50',frutta:'#FF9800',carne:'#F44336',pesce:'#2196F3',formaggio:'#FFC107',latticini:'#B0BEC5',cereali:'#795548',legumi:'#8BC34A',uova:'#FFEB3B',oli:'#FF5722',dolci:'#E91E63',bevande:'#00BCD4',salumi:'#FF7043',noci:'#A1887F',integratori:'#7E57C2'};
  return m[c] || '#9E9E9E';
}

function renderFoodList() {
  const q = (document.getElementById('foodSearch')?.value || '').toLowerCase().trim();
  let foods = FOODS;
  if (currentCategory !== 'all') foods = foods.filter(f => f.cat === currentCategory);
  if (q) foods = foods.filter(f => tFood(f.id).toLowerCase().includes(q));

  document.getElementById('foodCountPill').textContent =
    foods.length === FOODS.length ? `${FOODS.length}` : `${foods.length}/${FOODS.length}`;

  const list = document.getElementById('foodList');
  if (!foods.length) {
    list.innerHTML = `<div class="empty-state"><span class="material-icons-round">search_off</span><p>${t('no_results')}</p></div>`;
    return;
  }
  const byCat = {};
  foods.forEach(f => { (byCat[f.cat] = byCat[f.cat] || []).push(f); });
  let html = '';
  for (const [cat, items] of Object.entries(byCat)) {
    if (currentCategory === 'all') html += `<div class="section-title">${tCat(cat)}</div>`;
    items.forEach(f => {
      html += `<div class="food-item${selectedFood?.id===f.id?' selected':''}" onclick="selectFood(${f.id})">
        <div class="food-item-emoji" style="background:${catColor(f.cat)}20">${f.emoji}</div>
        <div class="food-item-info">
          <div class="food-item-name">${tFood(f.id)}</div>
          <div class="food-item-sub">${tCat(f.cat)} · ${f.kcal} kcal/100g</div>
        </div>
      </div>`;
    });
  }
  list.innerHTML = html;
}

function selectFood(id) {
  selectedFood = FOODS.find(f => f.id === id);
  currentWeight = 100;
  renderFoodList();
  renderCalcDetail();
  openMobileSheet();
}

function openMobileSheet() {
  const main = document.getElementById('calcMain');
  if (main && window.innerWidth <= 900) main.classList.add('open');
}

function closeMobileSheet() {
  const main = document.getElementById('calcMain');
  if (main) main.classList.remove('open');
}

function renderCalcDetail() {
  const f = selectedFood;
  if (!f) return;
  const m = currentWeight / 100;
  const kcal = (f.kcal*m).toFixed(0);
  const prot = (f.protein*m).toFixed(1);
  const carbs = (f.carbs*m).toFixed(1);
  const fat = (f.fat*m).toFixed(1);
  const fiber = (f.fiber*m).toFixed(1);

  const allergenTags = f.allergens.map(a => `<span class="tag tag-allergen"><span class="material-icons-round">warning</span>${tAllergen(a)}</span>`).join('');
  const intoTags = f.intolerances.map(i => `<span class="tag tag-intollerance"><span class="material-icons-round">do_not_disturb_on</span>${tAllergen(i)}</span>`).join('');

  document.getElementById('calcContent').innerHTML = `
    <div style="display:flex; gap:16px; align-items:flex-start; margin-bottom:16px">
      <div style="font-size:48px">${f.emoji}</div>
      <div style="flex:1">
        <h2 style="font-size:22px; font-weight:700">${tFood(f.id)}</h2>
        <span class="tag" style="background:var(--chip-bg);color:var(--on-bg-muted);text-transform:uppercase;letter-spacing:0.6px;font-size:10px">${tCat(f.cat)}</span>
      </div>
      <div style="text-align:right">
        <div style="font-size:32px; font-weight:700; color:var(--kcal-color)">${kcal}</div>
        <div style="font-size:12px; color:var(--on-bg-muted)">${t('kcal_per')} ${currentWeight}g</div>
      </div>
    </div>

    <div class="macros-grid">
      <div class="macro-box"><div class="v" style="color:var(--protein-color)">${prot}g</div><div class="l">${t('macro_protein')}</div></div>
      <div class="macro-box"><div class="v" style="color:var(--carb-color)">${carbs}g</div><div class="l">${t('macro_carbs')}</div></div>
      <div class="macro-box"><div class="v" style="color:var(--fat-color)">${fat}g</div><div class="l">${t('macro_fat')}</div></div>
      <div class="macro-box"><div class="v" style="color:var(--fiber-color)">${fiber}g</div><div class="l">${t('macro_fiber')}</div></div>
    </div>

    <div style="display:flex; align-items:center; gap:12px; margin-bottom:16px">
      <label style="font-weight:600; font-size:14px">${t('weight_label')}</label>
      <div style="display:flex; align-items:center; gap:6px; background:var(--input-bg); border:1.5px solid var(--border); border-radius:10px; padding:6px 10px">
        <button onclick="adjustWeight(-10)" style="background:var(--md-sys-color-primary);color:white;border:none;width:28px;height:28px;border-radius:50%;cursor:pointer;font-weight:700">−</button>
        <input type="number" id="weightInput" value="${currentWeight}" min="1" max="5000" oninput="updateWeight(this.value)" style="width:70px;text-align:center;border:none;background:transparent;font-family:inherit;font-size:18px;font-weight:700;color:var(--on-bg);outline:none">
        <button onclick="adjustWeight(10)" style="background:var(--md-sys-color-primary);color:white;border:none;width:28px;height:28px;border-radius:50%;cursor:pointer;font-weight:700">+</button>
        <span style="font-size:13px; color:var(--on-bg-muted)">g</span>
      </div>
    </div>

    ${allergenTags || intoTags ? `<div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:16px">${allergenTags}${intoTags}</div>` : ''}

    <button class="btn btn-orange" onclick="addToRecipe()">
      <span class="material-icons-round">add_shopping_cart</span>
      <span>${t('btn_add_recipe')}</span>
    </button>
  `;
}

function adjustWeight(d) {
  const v = Math.max(1, currentWeight + d);
  currentWeight = v;
  document.getElementById('weightInput').value = v;
  renderCalcDetail();
}

function updateWeight(v) {
  currentWeight = Math.max(1, parseInt(v)||1);
  renderCalcDetail();
}

function addToRecipe() {
  if (!selectedFood) return;
  recipe.push({ food: selectedFood, weight: currentWeight });
  showSnack(`${selectedFood.emoji} ${t('snack_added_recipe')}`);
  renderRecipeBox();
  openMobileSheet();
  // re-render section header to show "save recipe" button
  const headerActions = document.querySelector('.section-header .actions');
  if (headerActions && recipe.length === 1) {
    headerActions.insertAdjacentHTML('beforeend',
      `<button class="btn btn-green" onclick="openSaveRecipeModal()">
        <span class="material-icons-round">bookmark_add</span>
        <span>${t('save_recipe')}</span>
      </button>`);
  }
}

function renderRecipeBox() {
  const box = document.getElementById('recipeBox');
  if (!box) return;
  if (!recipe.length) { box.innerHTML = ''; return; }
  const T = recipe.reduce((a,i) => {
    const m = i.weight/100;
    a.kcal+=i.food.kcal*m; a.protein+=i.food.protein*m;
    a.carbs+=i.food.carbs*m; a.fat+=i.food.fat*m; a.fiber+=i.food.fiber*m;
    return a;
  }, {kcal:0,protein:0,carbs:0,fat:0,fiber:0});

  box.innerHTML = `
    <div style="margin-top:24px; padding-top:24px; border-top:1px solid var(--border)">
      <h3 style="margin-bottom:12px">🍽️ ${t('recipe_title').replace(/^[^\s]+\s/, '')}</h3>
      ${recipe.map((item, i) => `
        <div class="recipe-item-row">
          <span style="font-size:18px">${item.food.emoji}</span>
          <span style="flex:1; font-size:13px">${tFood(item.food.id)}</span>
          <input type="number" value="${item.weight}" min="1" max="5000" oninput="updateRecipeItem(${i}, this.value)">
          <span style="font-size:11px; color:var(--on-bg-muted)">g</span>
          <span style="font-weight:700; color:var(--kcal-color); min-width:50px; text-align:right" id="rk-${i}">${(item.food.kcal*item.weight/100).toFixed(0)} kcal</span>
          <button onclick="removeRecipeItem(${i})" style="background:none;border:none;cursor:pointer;color:var(--on-bg-subtle)">
            <span class="material-icons-round" style="font-size:18px">close</span>
          </button>
        </div>
      `).join('')}
      <div class="macros-grid" style="margin-top:16px">
        <div class="macro-box"><div class="v" style="color:var(--kcal-color)">${T.kcal.toFixed(0)}</div><div class="l">${t('macro_kcal')}</div></div>
        <div class="macro-box"><div class="v" style="color:var(--protein-color)">${T.protein.toFixed(1)}g</div><div class="l">${t('macro_protein')}</div></div>
        <div class="macro-box"><div class="v" style="color:var(--carb-color)">${T.carbs.toFixed(1)}g</div><div class="l">${t('macro_carbs')}</div></div>
        <div class="macro-box"><div class="v" style="color:var(--fat-color)">${T.fat.toFixed(1)}g</div><div class="l">${t('macro_fat')}</div></div>
      </div>
    </div>
  `;
}

function updateRecipeItem(i, v) {
  recipe[i].weight = Math.max(1, parseInt(v)||1);
  const el = document.getElementById(`rk-${i}`);
  if(el) el.textContent = (recipe[i].food.kcal*recipe[i].weight/100).toFixed(0) + ' kcal';
  // Update totals
  const T = recipe.reduce((a,it) => {
    const m = it.weight/100;
    a.kcal+=it.food.kcal*m;
    return a;
  }, {kcal:0});
  // Re-render only totals
  renderRecipeBox();
}

function removeRecipeItem(i) { recipe.splice(i,1); renderRecipeBox(); }
function clearRecipe() { recipe = []; renderRecipeBox(); switchSection('calculator'); showSnack(t('snack_cleared')); }

// ============ MODAL ============
function openModal(title, content) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalContent').innerHTML = content;
  document.getElementById('modalBackdrop').classList.add('show');
  document.getElementById('modal').classList.add('show');
}

function closeModal() {
  document.getElementById('modalBackdrop').classList.remove('show');
  document.getElementById('modal').classList.remove('show');
}

// Used when user explicitly finishes editing a plan
function closePlanAndReturn() {
  const planClientId = currentPlan?.client_id;
  currentPlan = null;
  closeModal();
  if (planClientId && currentClient && currentClient.id === planClientId) {
    openClient(planClientId);
  }
}

// ============ SAVE RECIPE ============
function openSaveRecipeModal() {
  if (!recipe.length) return;
  openModal(t('save_recipe'), `
    <div class="form-grid single">
      <div class="form-row">
        <label>${t('recipe_name') || 'Nome ricetta'}</label>
        <input type="text" id="newRecipeName" placeholder="${t('recipe_name_placeholder')}" required>
      </div>
      <div class="form-row">
        <label>${t('description') || 'Descrizione'}</label>
        <textarea id="newRecipeDesc" rows="3"></textarea>
      </div>
    </div>
    <div class="form-actions">
      <button class="btn btn-secondary" onclick="closeModal()">${t('cancel') || 'Annulla'}</button>
      <button class="btn btn-orange" onclick="saveRecipe()">${t('save') || 'Salva'}</button>
    </div>
  `);
}

async function saveRecipe() {
  const name = document.getElementById('newRecipeName').value.trim();
  const desc = document.getElementById('newRecipeDesc').value.trim();
  if (!name) return;
  try {
    await api('/recipes', {
      method: 'POST',
      body: {
        name, description: desc || null,
        items: recipe.map(it => ({ food_id: it.food.id, weight_g: it.weight })),
        tags: [],
      }
    });
    closeModal();
    showSnack(t('snack_recipe_saved') || 'Ricetta salvata');
  } catch(e) {
    showSnack(e.message, 'error');
  }
}

// ============ CLIENTS LIST ============
async function renderClientsList(container) {
  container.innerHTML = `
    <div class="section-header">
      <h2>${t('nav_clients')}</h2>
      <div class="actions">
        <button class="btn btn-orange" onclick="openNewClientModal()">
          <span class="material-icons-round">person_add</span>
          <span>${t('new_client') || 'Nuovo cliente'}</span>
        </button>
      </div>
    </div>
    <div class="search-bar">
      <span class="material-icons-round">search</span>
      <input type="text" id="clientSearch" placeholder="${t('search_clients') || 'Cerca cliente...'}" oninput="filterClients(this.value)">
    </div>
    <div id="clientsListContainer"></div>
  `;
  await loadClients();
}

async function loadClients(q = '') {
  try {
    const clients = await api('/clients' + (q ? `?q=${encodeURIComponent(q)}` : ''));
    const el = document.getElementById('clientsListContainer');
    if (!clients.length) {
      el.innerHTML = `<div class="empty-state">
        <span class="material-icons-round">people_outline</span>
        <h3>${t('no_clients') || 'Nessun cliente'}</h3>
        <p>${t('no_clients_hint') || 'Clicca su "Nuovo cliente" per aggiungere il primo.'}</p>
      </div>`;
      return;
    }
    el.innerHTML = `<div class="clients-grid">
      ${clients.map(c => {
        const initials = (c.first_name[0]||'')+(c.last_name[0]||'');
        const avatarHtml = c.avatar
          ? `<div class="client-avatar has-photo" style="background-image:url('${c.avatar}')"></div>`
          : `<div class="client-avatar">${initials}</div>`;
        return `
        <div class="client-card" onclick="openClient(${c.id})">
          ${avatarHtml}
          <div class="client-info">
            <div class="client-name">${escapeHTML(c.first_name)} ${escapeHTML(c.last_name)}</div>
            <div class="client-meta">${formatBirthAge(c.birth_date)}${c.target_kcal?` · ${c.target_kcal} kcal`:''}</div>
            ${(c.allergies?.length || c.intolerances?.length) ? `<div class="client-tags">
              ${c.allergies.slice(0,3).map(a => `<span class="mini-tag">${tAllergen(a)}</span>`).join('')}
              ${c.intolerances.slice(0,2).map(a => `<span class="mini-tag">${tAllergen(a)}</span>`).join('')}
            </div>` : ''}
          </div>
        </div>
      `;}).join('')}
    </div>`;
  } catch(e) { console.error(e); }
}

function filterClients(q) {
  clearTimeout(window._clientSearchT);
  window._clientSearchT = setTimeout(() => loadClients(q), 300);
}

function formatBirthAge(birthDate) {
  if (!birthDate) return '';
  const age = Math.floor((Date.now() - new Date(birthDate)) / (365.25*24*60*60*1000));
  return `${age} ${t('years') || 'anni'}`;
}

function escapeHTML(s) {
  return (s||'').replace(/[&<>"]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]));
}

// ============ NEW CLIENT ============
function openNewClientModal() {
  openModal(t('new_client') || 'Nuovo cliente', clientFormHTML(null));
  attachAllergenChips();
}

// Allergeni regolamento UE 1169/2011 + extra usati nel DB cibi
const EU_ALLERGENS = [
  'Glutine', 'Latte', 'Uova', 'Pesce', 'Crostacei', 'Molluschi',
  'Arachidi', 'Frutta a guscio', 'Soia', 'Sesamo', 'Sedano',
  'Senape', 'Solfiti', 'Lupini', 'Pistacchio'
];

// Intolleranze più frequenti in dietologia
const COMMON_INTOLERANCES = [
  'Lattosio', 'Glutine', 'Fruttosio', 'Istamina', 'Sorbitolo',
  'Saccarosio', 'FODMAP', 'Nichel', 'Salicilati', 'Caffeina',
  'Alcool', 'Glutammato', 'Solfiti', 'Tiramina'
];

function filterAllergenChips(input, gridId) {
  const q = input.value.toLowerCase().trim();
  document.querySelectorAll(`#${gridId} .checkbox-tag`).forEach(tag => {
    const name = tag.dataset.name || '';
    tag.style.display = !q || name.includes(q) ? '' : 'none';
  });
}

function clientFormHTML(client) {
  const c = client || {};
  const initials = (c.first_name?.[0]||'?') + (c.last_name?.[0]||'');
  const avatarStyle = c.avatar ? `background-image:url('${c.avatar}')` : '';
  const avatarShowInitials = c.avatar ? 'style="opacity:0"' : '';
  return `
    <form id="clientForm" onsubmit="return saveClient(event, ${client?.id || 'null'})">
      <input type="hidden" name="avatar" id="clientAvatarData" value="${c.avatar || ''}">
      <div class="avatar-upload">
        <div class="avatar-preview" id="avatarPreview" style="${avatarStyle}">
          <span id="avatarInitials" ${avatarShowInitials}>${escapeHTML(initials)}</span>
        </div>
        <div class="avatar-actions">
          <button type="button" onclick="document.getElementById('avatarFileInput').click()">
            <span class="material-icons-round">photo_camera</span>
            <span>${t('avatar_upload') || 'Carica foto'}</span>
          </button>
          ${c.avatar ? `<button type="button" onclick="clearAvatar()">
            <span class="material-icons-round">delete</span>
            <span>${t('avatar_remove') || 'Rimuovi'}</span>
          </button>` : ''}
          <input type="file" id="avatarFileInput" accept="image/*" onchange="handleAvatarFile(event)">
        </div>
      </div>
      <div class="form-grid">
        <div class="form-row"><label>${t('first_name') || 'Nome'} *</label><input name="first_name" value="${escapeHTML(c.first_name||'')}" required></div>
        <div class="form-row"><label>${t('last_name') || 'Cognome'} *</label><input name="last_name" value="${escapeHTML(c.last_name||'')}" required></div>
        <div class="form-row"><label>${t('birth_date') || 'Data nascita'}</label><input type="date" name="birth_date" value="${c.birth_date||''}"></div>
        <div class="form-row"><label>${t('sex') || 'Sesso'}</label>
          <select name="sex">
            <option value="">—</option>
            <option value="M" ${c.sex==='M'?'selected':''}>${t('male') || 'Maschio'}</option>
            <option value="F" ${c.sex==='F'?'selected':''}>${t('female') || 'Femmina'}</option>
            <option value="O" ${c.sex==='O'?'selected':''}>${t('other') || 'Altro'}</option>
          </select>
        </div>
        <div class="form-row"><label>Email</label><input type="email" name="email" value="${escapeHTML(c.email||'')}"></div>
        <div class="form-row"><label>${t('phone') || 'Telefono'}</label><input name="phone" value="${escapeHTML(c.phone||'')}"></div>
        <div class="form-row"><label>${t('height_cm') || 'Altezza (cm)'}</label><input type="number" step="0.1" min="50" max="250" name="height_cm" value="${c.height_cm||''}"></div>
        <div class="form-row"><label>${t('target_kcal') || 'Kcal obiettivo'}</label><input type="number" min="500" max="6000" name="target_kcal" value="${c.target_kcal||''}"></div>
        <div class="form-row"><label>${t('goal') || 'Obiettivo'}</label>
          <select name="goal">
            <option value="">—</option>
            <option value="lose" ${c.goal==='lose'?'selected':''}>${t('goal_lose') || 'Perdere peso'}</option>
            <option value="maintain" ${c.goal==='maintain'?'selected':''}>${t('goal_maintain') || 'Mantenere'}</option>
            <option value="gain" ${c.goal==='gain'?'selected':''}>${t('goal_gain') || 'Aumentare peso/massa'}</option>
          </select>
        </div>
        <div class="form-row"><label>${t('lifestyle') || 'Stile di vita'}</label>
          <select name="lifestyle">
            <option value="">—</option>
            <option value="sedentary" ${c.lifestyle==='sedentary'?'selected':''}>${t('lifestyle_sedentary') || 'Sedentario'}</option>
            <option value="light" ${c.lifestyle==='light'?'selected':''}>${t('lifestyle_light') || 'Attività leggera'}</option>
            <option value="moderate" ${c.lifestyle==='moderate'?'selected':''}>${t('lifestyle_moderate') || 'Attività moderata'}</option>
            <option value="active" ${c.lifestyle==='active'?'selected':''}>${t('lifestyle_active') || 'Attivo'}</option>
            <option value="sport" ${c.lifestyle==='sport'?'selected':''}>${t('lifestyle_sport') || 'Sportivo'}</option>
          </select>
        </div>
        <div class="form-row span2">
          <label>${t('allergens_label') || 'Allergeni'} <span style="color:var(--saft-orange); font-weight:700">(${(c.allergies||[]).length})</span></label>
          <input type="text" class="allergen-filter" placeholder="${t('filter_placeholder')||'Filtra...'}" oninput="filterAllergenChips(this, 'allergiesGrid')">
          <div class="checkbox-grid scrollable" id="allergiesGrid">
            ${EU_ALLERGENS.map(a => `
              <label class="checkbox-tag${(c.allergies||[]).includes(a)?' active':''}" data-type="allergies" data-val="${a}" data-name="${tAllergen(a).toLowerCase()}">
                <input type="checkbox" ${(c.allergies||[]).includes(a)?'checked':''}>${tAllergen(a)}
              </label>
            `).join('')}
          </div>
        </div>
        <div class="form-row span2">
          <label>${t('intolerances_label') || 'Intolleranze'} <span style="color:var(--saft-orange); font-weight:700">(${(c.intolerances||[]).length})</span></label>
          <input type="text" class="allergen-filter" placeholder="${t('filter_placeholder')||'Filtra...'}" oninput="filterAllergenChips(this, 'intolerancesGrid')">
          <div class="checkbox-grid scrollable" id="intolerancesGrid">
            ${COMMON_INTOLERANCES.map(a => `
              <label class="checkbox-tag${(c.intolerances||[]).includes(a)?' active':''}" data-type="intolerances" data-val="${a}" data-name="${tAllergen(a).toLowerCase()}">
                <input type="checkbox" ${(c.intolerances||[]).includes(a)?'checked':''}>${tAllergen(a)}
              </label>
            `).join('')}
          </div>
        </div>
        <div class="form-row span2"><label>${t('notes') || 'Note'}</label><textarea name="notes" rows="3">${escapeHTML(c.notes||'')}</textarea></div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">${t('cancel') || 'Annulla'}</button>
        <button type="submit" class="btn btn-orange">${t('save') || 'Salva'}</button>
      </div>
    </form>
  `;
}

// Avatar upload helpers - resize to 300x300 then save as base64
function handleAvatarFile(e) {
  const file = e.target.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) {
    showSnack(t('err_image_type') || 'Seleziona un file immagine', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = ev => {
    const img = new Image();
    img.onload = () => {
      const SIZE = 300;
      const canvas = document.createElement('canvas');
      canvas.width = SIZE; canvas.height = SIZE;
      const ctx = canvas.getContext('2d');
      // Crop to square, center
      const minDim = Math.min(img.width, img.height);
      const sx = (img.width - minDim) / 2;
      const sy = (img.height - minDim) / 2;
      ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, SIZE, SIZE);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      document.getElementById('clientAvatarData').value = dataUrl;
      const preview = document.getElementById('avatarPreview');
      preview.style.backgroundImage = `url('${dataUrl}')`;
      document.getElementById('avatarInitials').style.opacity = '0';
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
}

function clearAvatar() {
  document.getElementById('clientAvatarData').value = '';
  const preview = document.getElementById('avatarPreview');
  preview.style.backgroundImage = '';
  document.getElementById('avatarInitials').style.opacity = '1';
}

function attachAllergenChips() {
  document.querySelectorAll('.checkbox-tag').forEach(tag => {
    tag.addEventListener('click', e => {
      e.preventDefault();
      const cb = tag.querySelector('input');
      cb.checked = !cb.checked;
      tag.classList.toggle('active', cb.checked);
    });
  });
}

async function saveClient(e, id) {
  e.preventDefault();
  const form = e.target;
  const f = Object.fromEntries(new FormData(form));
  const data = {
    first_name: f.first_name,
    last_name: f.last_name,
    birth_date: f.birth_date || null,
    sex: f.sex || null,
    email: f.email || null,
    phone: f.phone || null,
    height_cm: f.height_cm ? parseFloat(f.height_cm) : null,
    target_kcal: f.target_kcal ? parseInt(f.target_kcal) : null,
    goal: f.goal || null,
    lifestyle: f.lifestyle || null,
    notes: f.notes || null,
    avatar: f.avatar || null,
    allergies: Array.from(document.querySelectorAll('#allergiesGrid .checkbox-tag.active')).map(t => t.dataset.val),
    intolerances: Array.from(document.querySelectorAll('#intolerancesGrid .checkbox-tag.active')).map(t => t.dataset.val),
  };
  try {
    if (id) {
      await api(`/clients/${id}`, { method: 'PATCH', body: data });
      showSnack(t('snack_client_updated') || 'Cliente aggiornato');
    } else {
      await api('/clients', { method: 'POST', body: data });
      showSnack(t('snack_client_created') || 'Cliente creato');
    }
    closeModal();
    if (currentSection === 'clients') loadClients();
    else if (currentSection === 'client-detail') openClient(id);
  } catch(err) {
    showSnack(err.message, 'error');
  }
  return false;
}

// ============ CLIENT DETAIL ============
async function openClient(id) {
  try {
    currentClient = await api(`/clients/${id}`);
    switchSection('client-detail');
  } catch(e) { showSnack(e.message, 'error'); }
}

async function renderClientDetail(container) {
  const c = currentClient;
  if (!c) { switchSection('clients'); return; }

  const measurements = await api(`/clients/${c.id}/measurements`);
  const plans = await api(`/clients/${c.id}/plans`);

  container.innerHTML = `
    <div class="section-header">
      <div>
        <button class="btn btn-secondary" onclick="switchSection('clients')">
          <span class="material-icons-round">arrow_back</span>
          <span>${t('back') || 'Indietro'}</span>
        </button>
      </div>
      <div class="actions">
        <button class="btn btn-secondary" onclick="openEditClient(${c.id})">
          <span class="material-icons-round">edit</span>
          <span>${t('edit') || 'Modifica'}</span>
        </button>
        <button class="btn btn-secondary" onclick="exportClient(${c.id})">
          <span class="material-icons-round">download</span>
          <span>${t('export_json') || 'Export JSON'}</span>
        </button>
        <button class="btn btn-danger" onclick="confirmDeleteClient(${c.id})">
          <span class="material-icons-round">delete</span>
        </button>
      </div>
    </div>

    <div style="display:flex; align-items:center; gap:16px; margin-bottom:24px">
      ${c.avatar
        ? `<div class="client-avatar has-photo" style="width:64px;height:64px;background-image:url('${c.avatar}')"></div>`
        : `<div class="client-avatar" style="width:64px;height:64px;font-size:22px">${(c.first_name[0]||'')+(c.last_name[0]||'')}</div>`}
      <div>
        <h2 style="font-size:24px">${escapeHTML(c.first_name)} ${escapeHTML(c.last_name)}</h2>
        <p style="color:var(--on-bg-muted); font-size:14px">${formatBirthAge(c.birth_date)}${c.sex?` · ${tSex(c.sex)}`:''}${c.height_cm?` · ${c.height_cm} cm`:''}</p>
      </div>
    </div>

    <div class="tabs-bar">
      <button class="tab-btn active" onclick="switchClientTab('info')"><span class="material-icons-round">info</span>${t('info') || 'Info'}</button>
      <button class="tab-btn" onclick="switchClientTab('measurements')"><span class="material-icons-round">monitor_weight</span>${t('measurements') || 'Misure'} (${measurements.length})</button>
      <button class="tab-btn" onclick="switchClientTab('plans')"><span class="material-icons-round">restaurant</span>${t('plans') || 'Piani'} (${plans.length})</button>
    </div>

    <div class="tab-content active" id="tab-info">
      <div class="client-detail">
        <div class="detail-card">
          <h3><span class="material-icons-round">person</span>${t('personal_info') || 'Informazioni'}</h3>
          <div class="detail-row"><span class="label">Email</span><span class="value">${c.email || '—'}</span></div>
          <div class="detail-row"><span class="label">${t('phone') || 'Telefono'}</span><span class="value">${c.phone || '—'}</span></div>
          <div class="detail-row"><span class="label">${t('birth_date') || 'Data nascita'}</span><span class="value">${c.birth_date || '—'}</span></div>
          <div class="detail-row"><span class="label">${t('height_cm') || 'Altezza'}</span><span class="value">${c.height_cm ? c.height_cm + ' cm' : '—'}</span></div>
        </div>
        <div class="detail-card">
          <h3><span class="material-icons-round">flag</span>${t('goal_section') || 'Obiettivi & Stile vita'}</h3>
          <div class="detail-row"><span class="label">${t('goal') || 'Obiettivo'}</span><span class="value">${c.goal ? t('goal_'+c.goal) : '—'}</span></div>
          <div class="detail-row"><span class="label">${t('lifestyle') || 'Stile vita'}</span><span class="value">${c.lifestyle ? t('lifestyle_'+c.lifestyle) : '—'}</span></div>
          <div class="detail-row"><span class="label">${t('target_kcal') || 'Kcal obiettivo'}</span><span class="value">${c.target_kcal || '—'}</span></div>
        </div>
        <div class="detail-card" style="grid-column: span 2">
          <h3><span class="material-icons-round">warning</span>${t('allergens_intolerances') || 'Allergeni & Intolleranze'}</h3>
          <div style="display:flex; flex-wrap:wrap; gap:6px">
            ${c.allergies?.map(a => `<span class="tag tag-allergen"><span class="material-icons-round">warning</span>${tAllergen(a)}</span>`).join('') || ''}
            ${c.intolerances?.map(a => `<span class="tag tag-intollerance"><span class="material-icons-round">do_not_disturb_on</span>${tAllergen(a)}</span>`).join('') || ''}
            ${(!c.allergies?.length && !c.intolerances?.length) ? `<span style="font-size:13px; color:var(--on-bg-subtle)">${t('no_allergens')}</span>` : ''}
          </div>
        </div>
        ${c.notes ? `<div class="detail-card" style="grid-column: span 2">
          <h3><span class="material-icons-round">notes</span>${t('notes') || 'Note'}</h3>
          <p style="font-size:14px; white-space:pre-wrap">${escapeHTML(c.notes)}</p>
        </div>` : ''}
      </div>
    </div>

    <div class="tab-content" id="tab-measurements">
      <div style="margin-bottom:16px">
        <button class="btn btn-orange" onclick="openNewMeasurementModal(${c.id})">
          <span class="material-icons-round">add</span>
          <span>${t('add_measurement') || 'Nuova misura'}</span>
        </button>
      </div>
      ${measurements.length ? `<div class="measurement-list">
        ${measurements.map(m => `
          <div class="measurement-row">
            <span class="measurement-date">${m.date}</span>
            <div class="measurement-values">
              ${m.weight_kg ? `<span>${t('weight') || 'Peso'}: <strong>${m.weight_kg} kg</strong></span>` : ''}
              ${m.body_fat_pct ? `<span>${t('body_fat') || 'Grasso'}: <strong>${m.body_fat_pct}%</strong></span>` : ''}
              ${m.muscle_mass_kg ? `<span>${t('muscle') || 'Muscolo'}: <strong>${m.muscle_mass_kg} kg</strong></span>` : ''}
              ${m.waist_cm ? `<span>${t('waist') || 'Vita'}: <strong>${m.waist_cm} cm</strong></span>` : ''}
              ${m.hip_cm ? `<span>${t('hip') || 'Fianchi'}: <strong>${m.hip_cm} cm</strong></span>` : ''}
            </div>
            <button class="btn btn-danger" onclick="deleteMeasurement(${m.id}, ${c.id})">
              <span class="material-icons-round" style="font-size:16px">delete</span>
            </button>
          </div>
        `).join('')}
      </div>` : `<div class="empty-state">
        <span class="material-icons-round">monitor_weight</span>
        <p>${t('no_measurements') || 'Nessuna misura registrata'}</p>
      </div>`}
    </div>

    <div class="tab-content" id="tab-plans">
      <div style="margin-bottom:16px">
        <button class="btn btn-orange" onclick="openNewPlanModal(${c.id})">
          <span class="material-icons-round">add</span>
          <span>${t('add_plan') || 'Nuovo piano'}</span>
        </button>
      </div>
      ${plans.length ? `<div class="clients-grid">
        ${plans.map(p => `
          <div class="client-card" onclick="openPlan(${p.id})">
            <div class="client-avatar" style="background:var(--md-sys-color-primary)">
              <span class="material-icons-round">${planTypeIcon(p.plan_type)}</span>
            </div>
            <div class="client-info">
              <div class="client-name">${escapeHTML(p.name)}</div>
              <div class="client-meta">${tPlanType(p.plan_type)} · ${p.start_date}${p.end_date ? ' → ' + p.end_date : ''}</div>
            </div>
          </div>
        `).join('')}
      </div>` : `<div class="empty-state">
        <span class="material-icons-round">restaurant</span>
        <p>${t('no_plans') || 'Nessun piano alimentare'}</p>
      </div>`}
    </div>
  `;
}

function tSex(s) { return ({M: t('male'), F: t('female'), O: t('other')}[s] || s); }
function tPlanType(t_) { return ({day: t('plan_day'), week: t('plan_week'), month: t('plan_month'), custom: t('plan_custom')}[t_] || t_); }
function planTypeIcon(t_) { return ({day:'today', week:'date_range', month:'calendar_month', custom:'edit_calendar'}[t_] || 'event'); }

function switchClientTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  event.target.closest('.tab-btn').classList.add('active');
  document.getElementById('tab-'+name).classList.add('active');
}

async function openEditClient(id) {
  const c = await api(`/clients/${id}`);
  openModal(t('edit_client') || 'Modifica cliente', clientFormHTML(c));
  attachAllergenChips();
}

async function confirmDeleteClient(id) {
  if (!confirm(t('confirm_delete_client') || 'Eliminare definitivamente questo cliente e tutti i suoi dati?')) return;
  try {
    await api(`/clients/${id}`, { method: 'DELETE' });
    showSnack(t('snack_client_deleted') || 'Cliente eliminato');
    switchSection('clients');
  } catch(e) { showSnack(e.message, 'error'); }
}

async function exportClient(id) {
  try {
    const data = await api(`/clients/${id}/export/json`);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `client-${data.client.last_name}-${data.client.first_name}-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  } catch(e) { showSnack(e.message, 'error'); }
}

// ============ MEASUREMENTS ============
function openNewMeasurementModal(clientId) {
  const today = new Date().toISOString().slice(0,10);
  openModal(t('add_measurement') || 'Nuova misura', `
    <form onsubmit="return saveMeasurement(event, ${clientId})">
      <div class="form-grid">
        <div class="form-row span2"><label>${t('date') || 'Data'} *</label><input type="date" name="date" value="${today}" required></div>
        <div class="form-row"><label>${t('weight') || 'Peso'} (kg)</label><input type="number" step="0.1" min="20" max="400" name="weight_kg"></div>
        <div class="form-row"><label>${t('body_fat') || 'Grasso'} (%)</label><input type="number" step="0.1" min="0" max="70" name="body_fat_pct"></div>
        <div class="form-row"><label>${t('muscle') || 'Muscolo'} (kg)</label><input type="number" step="0.1" min="0" max="200" name="muscle_mass_kg"></div>
        <div class="form-row"><label>${t('waist') || 'Vita'} (cm)</label><input type="number" step="0.1" min="30" max="250" name="waist_cm"></div>
        <div class="form-row"><label>${t('hip') || 'Fianchi'} (cm)</label><input type="number" step="0.1" min="30" max="250" name="hip_cm"></div>
        <div class="form-row span2"><label>${t('notes') || 'Note'}</label><textarea name="notes" rows="2"></textarea></div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">${t('cancel') || 'Annulla'}</button>
        <button type="submit" class="btn btn-orange">${t('save') || 'Salva'}</button>
      </div>
    </form>
  `);
}

async function saveMeasurement(e, clientId) {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const data = { date: f.date };
  ['weight_kg','body_fat_pct','muscle_mass_kg','waist_cm','hip_cm'].forEach(k => {
    if (f[k]) data[k] = parseFloat(f[k]);
  });
  if (f.notes) data.notes = f.notes;
  try {
    await api(`/clients/${clientId}/measurements`, { method: 'POST', body: data });
    closeModal();
    showSnack(t('snack_measurement_saved') || 'Misura salvata');
    openClient(clientId);
  } catch(err) { showSnack(err.message, 'error'); }
  return false;
}

async function deleteMeasurement(id, clientId) {
  if (!confirm(t('confirm_delete') || 'Eliminare?')) return;
  try {
    await api(`/measurements/${id}`, { method: 'DELETE' });
    openClient(clientId);
  } catch(e) { showSnack(e.message, 'error'); }
}

// ============ PLANS (placeholder for now - opens editor) ============
function openNewPlanModal(clientId) {
  const today = new Date().toISOString().slice(0,10);
  openModal(t('add_plan') || 'Nuovo piano', `
    <form onsubmit="return savePlan(event, ${clientId})">
      <div class="form-grid">
        <div class="form-row span2"><label>${t('plan_name') || 'Nome piano'} *</label><input name="name" required placeholder="${t('plan_name_placeholder') || 'es. Piano settimanale ottobre'}"></div>
        <div class="form-row"><label>${t('plan_type') || 'Tipo'} *</label>
          <select name="plan_type" required onchange="updatePlanDateFields(this)">
            <option value="day">${t('plan_day') || 'Giorno singolo'}</option>
            <option value="week">${t('plan_week') || 'Settimanale'}</option>
            <option value="month">${t('plan_month') || 'Mensile'}</option>
            <option value="custom">${t('plan_custom') || 'Personalizzato'}</option>
          </select>
        </div>
        <div class="form-row"><label>${t('start_date') || 'Data inizio'} *</label><input type="date" name="start_date" value="${today}" required></div>
        <div class="form-row span2" id="endDateRow" style="display:none"><label>${t('end_date') || 'Data fine'}</label><input type="date" name="end_date"></div>
        <div class="form-row"><label>${t('target_kcal') || 'Kcal obiettivo'}</label><input type="number" min="500" max="6000" name="target_kcal"></div>
        <div class="form-row span2"><label>${t('notes') || 'Note'}</label><textarea name="notes" rows="2"></textarea></div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">${t('cancel') || 'Annulla'}</button>
        <button type="submit" class="btn btn-orange">${t('create') || 'Crea piano'}</button>
      </div>
      <p style="font-size:12px; color:var(--on-bg-muted); margin-top:12px">${t('plan_hint') || 'Dopo aver creato il piano potrai aggiungere i pasti.'}</p>
    </form>
  `);
}

function updatePlanDateFields(sel) {
  document.getElementById('endDateRow').style.display = sel.value === 'custom' ? 'flex' : 'none';
}

async function savePlan(e, clientId) {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const data = {
    name: f.name,
    plan_type: f.plan_type,
    start_date: f.start_date,
    end_date: f.end_date || null,
    target_kcal: f.target_kcal ? parseInt(f.target_kcal) : null,
    notes: f.notes || null,
    meals: [],
  };
  try {
    const plan = await api(`/clients/${clientId}/plans`, { method: 'POST', body: data });
    closeModal();
    showSnack(t('snack_plan_created') || 'Piano creato');
    openPlan(plan.id);
  } catch(err) { showSnack(err.message, 'error'); }
  return false;
}

// ============ PLAN EDITOR ============
let currentPlan = null;
let currentDayOffset = 0;

const STANDARD_MEALS = [
  { type: 'breakfast', icon: 'wb_sunny', i18n: 'meal_breakfast' },
  { type: 'lunch', icon: 'restaurant', i18n: 'meal_lunch' },
  { type: 'dinner', icon: 'nights_stay', i18n: 'meal_dinner' },
  { type: 'snacks', icon: 'cookie', i18n: 'meal_snacks' },
];

async function openPlan(planId) {
  // Always fetch fresh from server to avoid stale state
  try {
    currentPlan = await api(`/plans/${planId}`);
    currentDayOffset = 0;
    renderPlanEditor();
  } catch (e) {
    showSnack(t('err_load_plan') || 'Errore caricamento piano', 'error');
  }
}

let _savingTimeout = null;
function showSaving() {
  const sb = document.getElementById('snackbar');
  if (!sb) return;
  document.getElementById('snackMsg').textContent = t('saving') || 'Salvataggio…';
  document.getElementById('snackIcon').textContent = 'cloud_upload';
  sb.classList.remove('error');
  sb.classList.add('show');
  clearTimeout(_savingTimeout);
  _savingTimeout = setTimeout(() => sb.classList.remove('show'), 1200);
}

function showSaved() {
  const sb = document.getElementById('snackbar');
  if (!sb) return;
  document.getElementById('snackMsg').textContent = t('saved') || 'Salvato';
  document.getElementById('snackIcon').textContent = 'cloud_done';
  sb.classList.remove('error');
  sb.classList.add('show');
  clearTimeout(_savingTimeout);
  _savingTimeout = setTimeout(() => sb.classList.remove('show'), 1500);
}

function planNumDays(p) {
  if (p.plan_type === 'day') return 1;
  if (p.plan_type === 'week') return 7;
  if (p.plan_type === 'month') return 30;
  if (p.plan_type === 'custom' && p.end_date && p.start_date) {
    const d = (new Date(p.end_date) - new Date(p.start_date)) / 86400000 + 1;
    return Math.max(1, Math.min(365, Math.round(d)));
  }
  return 7;
}

function planDayLabel(p, offset) {
  const start = new Date(p.start_date);
  start.setDate(start.getDate() + offset);
  const days = [t('day_sun'), t('day_mon'), t('day_tue'), t('day_wed'), t('day_thu'), t('day_fri'), t('day_sat')];
  return { weekday: days[start.getDay()] || '', date: start.toISOString().slice(5,10) };
}

function mealLabel(m) {
  if (m.custom_name) return m.custom_name;
  const std = STANDARD_MEALS.find(s => s.type === m.meal_type);
  return std ? t(std.i18n) : m.meal_type;
}

function mealIcon(meal_type) {
  const std = STANDARD_MEALS.find(s => s.type === meal_type);
  return std ? std.icon : 'restaurant_menu';
}

function getDayMeals(offset) {
  return currentPlan.meals.filter(m => m.day_offset === offset);
}

function calcMealKcal(meal) {
  return meal.items.reduce((sum, it) => {
    const food = FOODS.find(f => f.id === it.food_id);
    return sum + (food ? food.kcal * it.weight_g / 100 : 0);
  }, 0);
}

function calcDayTotals(offset) {
  const meals = getDayMeals(offset);
  return meals.reduce((a, m) => {
    m.items.forEach(it => {
      const food = FOODS.find(f => f.id === it.food_id);
      if (!food) return;
      const mul = it.weight_g / 100;
      a.kcal += food.kcal * mul;
      a.protein += food.protein * mul;
      a.carbs += food.carbs * mul;
      a.fat += food.fat * mul;
      a.fiber += food.fiber * mul;
    });
    return a;
  }, {kcal:0,protein:0,carbs:0,fat:0,fiber:0});
}

function renderPlanEditor() {
  const p = currentPlan;
  const numDays = planNumDays(p);

  openModal(p.name, `
    <div class="plan-editor">
      <div class="plan-summary">
        <div class="plan-summary-info">
          <h3>${escapeHTML(p.name)}</h3>
          <p>${tPlanType(p.plan_type)} · ${p.start_date}${p.end_date?' → '+p.end_date:''}${p.target_kcal?` · ${p.target_kcal} kcal/${t('day_word')||'giorno'}`:''}</p>
        </div>
        <div style="display:flex; gap:6px">
          <button class="icon-btn" onclick="exportPlanJson(${p.id})" title="${t('export_json')||'Export'}">
            <span class="material-icons-round">download</span>
          </button>
          <button class="icon-btn danger" onclick="deletePlan(${p.id}, ${p.client_id})" title="${t('delete')||'Elimina'}">
            <span class="material-icons-round">delete</span>
          </button>
        </div>
      </div>

      <div class="plan-day-tabs" id="planDayTabs">
        ${Array.from({length: numDays}, (_, i) => {
          const lbl = planDayLabel(p, i);
          const hasMeals = getDayMeals(i).length > 0;
          return `<div class="day-tab${i===currentDayOffset?' active':''}${hasMeals?' has-meals':''}" onclick="switchPlanDay(${i})">
            <small>${lbl.weekday}</small>${lbl.date}
          </div>`;
        }).join('')}
      </div>

      <div id="planDayContent"></div>

      <div class="form-actions" style="margin-top:20px; padding-top:16px; border-top:1px solid var(--border)">
        <button class="btn btn-orange" onclick="closePlanAndReturn()">
          <span class="material-icons-round">check</span>
          <span>${t('done') || 'Fatto'}</span>
        </button>
      </div>
    </div>
  `);

  renderPlanDayContent();
}

function switchPlanDay(offset) {
  currentDayOffset = offset;
  document.querySelectorAll('#planDayTabs .day-tab').forEach((t, i) => t.classList.toggle('active', i === offset));
  renderPlanDayContent();
}

function renderPlanDayContent() {
  const offset = currentDayOffset;
  const dayMeals = getDayMeals(offset);
  const totals = calcDayTotals(offset);
  const target = currentPlan.target_kcal;
  const pct = target ? Math.min(150, Math.round(totals.kcal / target * 100)) : 0;
  const pctClass = pct > 110 ? 'way-over' : (pct > 100 ? 'over' : '');

  // Get meals to display: standard 4 + any custom ones already added
  const displayMeals = [];
  STANDARD_MEALS.forEach(s => {
    const existing = dayMeals.find(m => m.meal_type === s.type);
    displayMeals.push({ meal_type: s.type, ...existing });
  });
  // Add custom meals (not in standard)
  dayMeals.filter(m => !STANDARD_MEALS.find(s => s.type === m.meal_type)).forEach(m => {
    displayMeals.push(m);
  });

  document.getElementById('planDayContent').innerHTML = `
    ${displayMeals.map(meal => renderMealSlot(meal)).join('')}

    <button class="btn btn-secondary" onclick="addCustomMeal()" style="width:100%; justify-content:center">
      <span class="material-icons-round">add</span>
      <span>${t('add_custom_meal') || 'Pasto personalizzato'}</span>
    </button>

    <div class="day-totals">
      <div><div class="v" style="color:var(--kcal-color)">${totals.kcal.toFixed(0)}</div><div class="l">${t('macro_kcal')}</div></div>
      <div><div class="v" style="color:var(--protein-color)">${totals.protein.toFixed(1)}g</div><div class="l">${t('macro_protein')}</div></div>
      <div><div class="v" style="color:var(--carb-color)">${totals.carbs.toFixed(1)}g</div><div class="l">${t('macro_carbs')}</div></div>
      <div><div class="v" style="color:var(--fat-color)">${totals.fat.toFixed(1)}g</div><div class="l">${t('macro_fat')}</div></div>
      <div><div class="v" style="color:var(--fiber-color)">${totals.fiber.toFixed(1)}g</div><div class="l">${t('macro_fiber')}</div></div>
    </div>
    ${target ? `<div class="kcal-progress">
      <span>${totals.kcal.toFixed(0)} / ${target} kcal</span>
      <div class="bar"><div class="fill ${pctClass}" style="width:${pct}%"></div></div>
      <span>${pct}%</span>
    </div>` : ''}
  `;
}

function renderMealSlot(meal) {
  const isEmpty = !meal.items || meal.items.length === 0;
  const kcal = meal.items ? calcMealKcal(meal) : 0;
  const label = mealLabel(meal);
  const icon = mealIcon(meal.meal_type);
  const isCustom = !STANDARD_MEALS.find(s => s.type === meal.meal_type);

  return `
    <div class="meal-slot" data-meal-type="${meal.meal_type}">
      <div class="meal-slot-header">
        <div class="meal-slot-title">
          <span class="material-icons-round">${icon}</span>
          <span>${escapeHTML(label)}</span>
        </div>
        ${!isEmpty ? `<div class="meal-slot-kcal">${kcal.toFixed(0)} kcal</div>` : ''}
        <div class="meal-slot-actions">
          ${isCustom ? `<button class="icon-btn" onclick="renameMeal('${meal.meal_type}')" title="${t('rename') || 'Rinomina'}">
            <span class="material-icons-round">edit</span>
          </button>` : ''}
          ${!isEmpty ? `<button class="icon-btn danger" onclick="clearMeal('${meal.meal_type}')" title="${t('clear') || 'Svuota'}">
            <span class="material-icons-round">delete_sweep</span>
          </button>` : ''}
        </div>
      </div>
      ${isEmpty ? `<div class="meal-empty">${t('meal_empty') || 'Nessun alimento'}</div>` : `
        <div class="meal-items">
          ${meal.items.map((it, i) => {
            const food = FOODS.find(f => f.id === it.food_id);
            if (!food) return '';
            const itemKcal = food.kcal * it.weight_g / 100;
            return `
              <div class="meal-item-row">
                <span class="emoji">${food.emoji}</span>
                <span class="name">${tFood(food.id)}</span>
                <input type="number" class="weight" value="${it.weight_g}" min="1" max="5000"
                       onchange="updateMealItemWeight('${meal.meal_type}', ${i}, this.value)">
                <span style="font-size:11px; color:var(--on-bg-muted)">g</span>
                <span class="kcal">${itemKcal.toFixed(0)}</span>
                <button class="remove" onclick="removeMealItem('${meal.meal_type}', ${i})">
                  <span class="material-icons-round">close</span>
                </button>
              </div>
            `;
          }).join('')}
        </div>
      `}
      <div class="add-food-bar">
        <button class="btn btn-secondary" onclick="openFoodPicker('${meal.meal_type}')">
          <span class="material-icons-round">add</span>
          <span>${t('add_food') || 'Aggiungi cibo'}</span>
        </button>
        <button class="btn btn-secondary" onclick="openRecipePicker('${meal.meal_type}')">
          <span class="material-icons-round">menu_book</span>
          <span>${t('from_recipe') || 'Da ricetta'}</span>
        </button>
      </div>
    </div>
  `;
}

function getOrCreateMeal(mealType) {
  let meal = currentPlan.meals.find(m => m.day_offset === currentDayOffset && m.meal_type === mealType);
  if (!meal) {
    meal = { day_offset: currentDayOffset, meal_type: mealType, items: [], notes: null };
    currentPlan.meals.push(meal);
  }
  return meal;
}

async function persistMeal(meal) {
  showSaving();
  await api(`/plans/${currentPlan.id}/meals`, {
    method: 'POST',
    body: {
      day_offset: meal.day_offset,
      meal_type: meal.meal_type,
      items: meal.items.map(it => ({food_id: it.food_id, weight_g: parseFloat(it.weight_g)})),
      notes: meal.notes || null,
      custom_name: meal.custom_name || null,
    }
  });
  // Always reload plan from server to keep UI in sync
  currentPlan = await api(`/plans/${currentPlan.id}`);
  showSaved();
}

async function updateMealItemWeight(mealType, idx, weight) {
  const meal = getOrCreateMeal(mealType);
  meal.items[idx].weight_g = Math.max(1, parseFloat(weight) || 1);
  await persistMeal(meal);
  renderPlanDayContent();
}

async function removeMealItem(mealType, idx) {
  const meal = getOrCreateMeal(mealType);
  meal.items.splice(idx, 1);
  await persistMeal(meal);
  renderPlanDayContent();
}

async function clearMeal(mealType) {
  if (!confirm(t('confirm_clear_meal') || 'Svuotare questo pasto?')) return;
  const meal = getOrCreateMeal(mealType);
  meal.items = [];
  await persistMeal(meal);
  renderPlanDayContent();
}

// ============ FOOD PICKER MODAL ============
let pickerTargetMeal = null;
let pickerSearchTimer = null;

function openFoodPicker(mealType) {
  pickerTargetMeal = mealType;
  openModal(t('add_food') || 'Aggiungi cibo', `
    <div class="food-picker-search">
      <span class="material-icons-round">search</span>
      <input type="text" id="foodPickerInput" placeholder="${t('search_placeholder')}" oninput="filterFoodPicker(this.value)" autofocus>
    </div>
    <div class="food-picker-list" id="foodPickerList"></div>
  `);
  filterFoodPicker('');
}

function filterFoodPicker(q) {
  q = q.toLowerCase().trim();
  let foods = FOODS;
  if (q) foods = foods.filter(f => tFood(f.id).toLowerCase().includes(q));
  foods = foods.slice(0, 80); // limit for performance
  const list = document.getElementById('foodPickerList');
  if (!foods.length) {
    list.innerHTML = `<div class="empty-state"><p>${t('no_results')}</p></div>`;
    return;
  }
  list.innerHTML = foods.map(f => `
    <div class="food-picker-item">
      <span style="font-size:20px">${f.emoji}</span>
      <div>
        <div style="font-size:13px; font-weight:500">${tFood(f.id)}</div>
        <div style="font-size:11px; color:var(--on-bg-muted)">${f.kcal} kcal/100g</div>
      </div>
      <input type="number" id="pickerW-${f.id}" value="100" min="1" max="5000">
      <button class="add-btn" onclick="addFoodToMeal(${f.id})">${t('add') || 'Aggiungi'}</button>
    </div>
  `).join('');
}

async function addFoodToMeal(foodId) {
  const weight = parseFloat(document.getElementById(`pickerW-${foodId}`).value) || 100;
  const meal = getOrCreateMeal(pickerTargetMeal);
  meal.items.push({ food_id: foodId, weight_g: weight });
  await persistMeal(meal);
  showSnack(t('snack_food_added') || 'Cibo aggiunto');
  // close picker and refresh underneath
  closeModal();
  setTimeout(() => renderPlanEditor(), 100);
}

// ============ RECIPE PICKER ============
async function openRecipePicker(mealType) {
  pickerTargetMeal = mealType;
  const recipes = await api('/recipes');
  if (!recipes.length) {
    showSnack(t('no_recipes_to_use') || 'Nessuna ricetta salvata. Creane una nel Calcolatore.', 'error');
    return;
  }
  openModal(t('from_recipe') || 'Da ricetta', `
    <div class="food-picker-list">
      ${recipes.map(r => {
        const kcal = r.items.reduce((s, it) => {
          const f = FOODS.find(ff => ff.id === it.food_id);
          return s + (f ? f.kcal * it.weight_g / 100 : 0);
        }, 0);
        return `
          <div class="food-picker-item" onclick="useRecipeForMeal(${r.id})" style="grid-template-columns:auto 1fr auto">
            <span style="font-size:20px">📖</span>
            <div>
              <div style="font-size:13px; font-weight:500">${escapeHTML(r.name)}</div>
              <div style="font-size:11px; color:var(--on-bg-muted)">${r.items.length} ${t('ingredients')} · ${kcal.toFixed(0)} kcal</div>
            </div>
            <button class="add-btn">${t('use') || 'Usa'}</button>
          </div>
        `;
      }).join('')}
    </div>
  `);
}

async function useRecipeForMeal(recipeId) {
  const recipes = await api('/recipes');
  const r = recipes.find(rr => rr.id === recipeId);
  if (!r) return;
  const meal = getOrCreateMeal(pickerTargetMeal);
  // Append recipe items
  r.items.forEach(it => meal.items.push({ food_id: it.food_id, weight_g: it.weight_g }));
  await persistMeal(meal);
  showSnack(t('snack_recipe_imported') || 'Ricetta importata');
  closeModal();
  setTimeout(() => renderPlanEditor(), 100);
}

// ============ CUSTOM MEALS ============
function addCustomMeal() {
  const name = prompt(t('custom_meal_name') || 'Nome del pasto:');
  if (!name || !name.trim()) return;
  // Use a unique meal_type key
  const slug = 'custom_' + Date.now();
  const meal = { day_offset: currentDayOffset, meal_type: slug, custom_name: name.trim(), items: [], notes: null };
  currentPlan.meals.push(meal);
  renderPlanDayContent();
  // Open food picker immediately
  setTimeout(() => openFoodPicker(slug), 100);
}

function renameMeal(mealType) {
  const meal = currentPlan.meals.find(m => m.day_offset === currentDayOffset && m.meal_type === mealType);
  if (!meal) return;
  const name = prompt(t('rename_meal') || 'Nuovo nome:', meal.custom_name || '');
  if (!name || !name.trim()) return;
  meal.custom_name = name.trim();
  persistMeal(meal).then(() => renderPlanDayContent());
}

async function exportPlanJson(planId) {
  const plan = await api(`/plans/${planId}`);
  const blob = new Blob([JSON.stringify(plan, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `plan-${plan.name.replace(/[^a-z0-9]/gi,'_')}-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

async function deletePlan(planId, clientId) {
  if (!confirm(t('confirm_delete') || 'Eliminare?')) return;
  try {
    await api(`/plans/${planId}`, { method: 'DELETE' });
    closeModal();
    openClient(clientId);
  } catch(e) { showSnack(e.message, 'error'); }
}

// ============ RECIPES ============
async function renderRecipes(container) {
  const recipes = await api('/recipes');
  container.innerHTML = `
    <div class="section-header">
      <h2>${t('nav_recipes')}</h2>
    </div>
    ${recipes.length ? `<div class="clients-grid">
      ${recipes.map(r => {
        const totals = r.items.reduce((a, it) => {
          const f = FOODS.find(ff => ff.id === it.food_id);
          if (f) a.kcal += f.kcal * it.weight_g / 100;
          return a;
        }, {kcal:0});
        return `<div class="client-card">
          <div class="client-avatar" style="background:var(--md-sys-color-primary)"><span class="material-icons-round">menu_book</span></div>
          <div class="client-info">
            <div class="client-name">${escapeHTML(r.name)}</div>
            <div class="client-meta">${r.items.length} ${t('ingredients') || 'ingredienti'} · ${totals.kcal.toFixed(0)} kcal</div>
            ${r.description ? `<div style="font-size:12px; margin-top:4px; color:var(--on-bg-muted)">${escapeHTML(r.description.slice(0,80))}</div>` : ''}
          </div>
          <button class="btn btn-danger" onclick="event.stopPropagation(); deleteRecipe(${r.id})">
            <span class="material-icons-round" style="font-size:16px">delete</span>
          </button>
        </div>`;
      }).join('')}
    </div>` : `<div class="empty-state">
      <span class="material-icons-round">menu_book</span>
      <h3>${t('no_recipes') || 'Nessuna ricetta'}</h3>
      <p>${t('no_recipes_hint') || 'Crea ricette nel Calcolatore e salvale qui per riutilizzarle.'}</p>
    </div>`}
  `;
}

async function deleteRecipe(id) {
  if (!confirm(t('confirm_delete') || 'Eliminare?')) return;
  try {
    await api(`/recipes/${id}`, { method: 'DELETE' });
    renderRecipes(document.getElementById('mainContainer').firstElementChild);
  } catch(e) { showSnack(e.message, 'error'); }
}

// ============ SNACKBAR ============
function showSnack(msg, type = 'success') {
  const sb = document.getElementById('snackbar');
  sb.classList.toggle('error', type === 'error');
  document.getElementById('snackMsg').textContent = msg;
  document.getElementById('snackIcon').textContent = type === 'error' ? 'error' : 'check_circle';
  sb.classList.add('show');
  clearTimeout(sb._t);
  sb._t = setTimeout(() => sb.classList.remove('show'), 2800);
}

// ============ INIT ============
document.addEventListener('DOMContentLoaded', init);
